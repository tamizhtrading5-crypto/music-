// Build the animated equalizer bars inside the hero player card.
(function () {
  var eq = document.getElementById('eq');
  if (!eq) return;

  var barCount = 24;
  var delays = [0, 0.15, 0.3, 0.1, 0.25, 0.05, 0.35, 0.2];

  for (var i = 0; i < barCount; i++) {
    var bar = document.createElement('span');
    var delay = delays[i % delays.length];
    var duration = 0.8 + (i % 5) * 0.12;
    bar.style.animationDelay = delay + 's';
    bar.style.animationDuration = duration + 's';
    eq.appendChild(bar);
  }
})();
