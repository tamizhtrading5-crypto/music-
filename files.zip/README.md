# Wavelength — music bot landing page

A single-page, responsive landing site for a Discord music bot. Static HTML/CSS/JS, no build step required.

## File structure

```
.
├── index.html            Main page
├── assets/
│   ├── css/style.css     All styling (colors, type, layout, animation)
│   ├── js/script.js      Builds the animated equalizer bars in the hero
│   └── img/               Empty — drop a logo/screenshot here if you add one
└── README.md
```

## Before you publish

A few placeholders need to be swapped for your real values. Search for these in `index.html`:

| Placeholder | Where | Replace with |
|---|---|---|
| `YOUR_CLIENT_ID` | 3 "Add to Discord" buttons | Your bot's Discord application client ID |
| `Wavelength` | Throughout | Your bot's real name (also update `<title>` and the meta description) |
| `40,000+ servers` / `99.98%` / `40k+` / `<80ms` | Hero stats | Your real numbers, or remove the stat row if you don't have them yet |
| `hello@wavelength.example` | Footer | Your support email |
| Support server / Terms / Privacy links | Footer | Real URLs |

The Discord invite URL follows this pattern:

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot%20applications.commands&permissions=PERMISSIONS_INTEGER
```

Generate the permissions integer for your bot in the [Discord Developer Portal](https://discord.com/developers/applications) under your application's OAuth2 → URL Generator.

## Customizing content

- **Features** (`#features` section): six cards in `index.html`, each with an icon, heading, and one sentence. Edit freely — the grid reflows automatically for 1–6+ cards.
- **Commands** (`#commands` section): the terminal-style list mirrors your bot's actual slash commands. Update the `<li>` entries to match what your bot supports.
- **FAQ**: plain `<details>/<summary>` elements — accessible and require no JavaScript.

## Design notes

- Dark theme with a two-color signal system: amber (`#F5A623`) for primary actions and the "now playing" state, teal (`#2FD9C4`) for secondary/command syntax.
- Display type is Space Grotesk, body is Inter, and command/technical text uses JetBrains Mono — loaded from Google Fonts.
- The equalizer bars in the nav and hero player card are pure CSS animation and respect `prefers-reduced-motion`.
- Fully responsive down to mobile; the hero grid and command terminal stack on narrow screens.

## Running locally

No build tools needed. Just open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.
